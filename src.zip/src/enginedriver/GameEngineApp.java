package enginedriver;

import GameEngine.model.GameModel;
import GameEngine.controller.Controller;
// import GameEngine.controller.gui.GUIController; // to be implemented by GUI team
// import GameEngine.view.MainGameView;           // to be implemented by GUI team

import java.io.*;
import javax.swing.*;

/**
 * The entry point for the Adventure Game Engine.
 * Supports multiple modes: text, batch, and GUI.
 */
public class GameEngineApp {

  public static void main(String[] args) throws IOException {
    if (args.length < 2) {
      System.out.println("Usage:\n" +
              "  java -jar game_engine.jar <file> -text\n" +
              "  java -jar game_engine.jar <file> -graphics\n" +
              "  java -jar game_engine.jar <file> -batch <source>\n" +
              "  java -jar game_engine.jar <file> -batch <source> <target>");
      return;
    }

    String gameFile = args[0];
    String mode = args[1];
    GameModel model = GameModel.load(gameFile);

    switch (mode) {
      case "-text":
        new Controller(model, new InputStreamReader(System.in), System.out).run();
        break;

      case "-graphics":
        SwingUtilities.invokeLater(() -> {
          try {
            // GUIController guiController = new GUIController(model);
            // guiController.start();
            System.out.println("[INFO] GUI Mode: placeholder for GUI startup.");
          } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to launch GUI mode.");
          }
        });
        break;

      case "-batch":
        if (args.length < 3) {
          System.out.println("Error: Missing batch input file.");
          return;
        }
        Reader batchInput = new FileReader(args[2]);
        Appendable batchOutput = (args.length == 4) ? new FileWriter(args[3]) : System.out;
        new Controller(model, batchInput, batchOutput).run();
        break;

      default:
        System.out.println("Invalid mode: " + mode);
        break;
    }
  }
}
