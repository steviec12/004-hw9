package GameEngine.controller.gui;

import GameEngine.model.GameModel;
import GameEngine.model.Room;

import javax.swing.*;
import java.awt.*;
import java.util.stream.Collectors;

public class GUIController {
  private final GameModel model;
  private final JFrame frame;
  private final JTextArea gameOutput;

  /**
   * Constructs a new GUIController for the specified GameModel.
   * Initializes the game window and UI components.
   *
   * @param model the GameModel to control
   */
  public GUIController(GameModel model) {
    this.model = model;
    this.frame = new JFrame("Adventure Game");
    this.gameOutput = new JTextArea(15, 50);
    initializeUI();
  }

  /**
   * Initializes the Swing UI components and layout for the game window.
   */
  private void initializeUI() {
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());

    JPanel buttons = new JPanel();
    buttons.setLayout(new GridLayout(2, 4));

    JButton northBtn = new JButton("North");
    JButton southBtn = new JButton("South");
    JButton eastBtn = new JButton("East");
    JButton westBtn = new JButton("West");
    JButton takeBtn = new JButton("Take Item");
    JButton dropBtn = new JButton("Drop Item");
    JButton useBtn = new JButton("Use Item");
    JButton answerBtn = new JButton("Answer Puzzle");
    JButton lookBtn = new JButton("Look Around");
    JButton inventoryBtn = new JButton("Inventory");

    northBtn.addActionListener(e -> move("N"));
    southBtn.addActionListener(e -> move("S"));
    eastBtn.addActionListener(e -> move("E"));
    westBtn.addActionListener(e -> move("W"));

    takeBtn.addActionListener(e -> {
      String item = JOptionPane.showInputDialog(frame, "Enter item to take:");
      if (item != null) takeItem(item.trim());
    });

    dropBtn.addActionListener(e -> {
      String item = JOptionPane.showInputDialog(frame, "Enter item to drop:");
      if (item != null) dropItem(item.trim());
    });

    useBtn.addActionListener(e -> {
      String item = JOptionPane.showInputDialog(frame, "Enter item to use:");
      if (item != null) useItem(item.trim());
    });

    answerBtn.addActionListener(e -> {
      String answer = JOptionPane.showInputDialog(frame, "Enter answer:");
      if (answer != null) answerPuzzle(answer.trim());
    });

    lookBtn.addActionListener(e -> refresh());

    inventoryBtn.addActionListener(e -> {
      String inventory = model.getPlayer().getInventory().stream()
              .map(Object::toString)
              .collect(Collectors.joining("\n"));
      JOptionPane.showMessageDialog(frame, "Inventory:\n" + inventory);
    });



    buttons.add(northBtn);
    buttons.add(southBtn);
    buttons.add(eastBtn);
    buttons.add(westBtn);
    buttons.add(takeBtn);
    buttons.add(dropBtn);
    buttons.add(useBtn);
    buttons.add(answerBtn);

    JPanel bottomButtons = new JPanel();
    bottomButtons.add(lookBtn);
    bottomButtons.add(inventoryBtn);

    gameOutput.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(gameOutput);

    panel.add(buttons, BorderLayout.NORTH);
    panel.add(scrollPane, BorderLayout.CENTER);
    panel.add(bottomButtons, BorderLayout.SOUTH);

    frame.setContentPane(panel);
    frame.pack();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);

    refresh();
  }

  /**
   * Attempts to move the player in the specified direction.
   * If successful, updates the view. If not, shows an error message.
   *
   * @param direction the direction to move (e.g., "N", "S", "E", "W")
   */
  private void move(String direction) {
    boolean success = model.getPlayer().move(direction);
    if (!success) {
      JOptionPane.showMessageDialog(frame, "You can't go " + direction);
    }
    refresh();
  }

  /**
   * Attempts to take an item from the current room.
   *
   * @param item the name of the item to take
   */
  private void takeItem(String item) {
    boolean success = model.getPlayer().take(item);
    if (!success) {
      JOptionPane.showMessageDialog(frame, "No such item here.");
    }
    refresh();
  }

  /**
   * Attempts to drop an item from the player's inventory.
   *
   * @param item the name of the item to drop
   */
  private void dropItem(String item) {
    boolean success = model.getPlayer().drop(item);
    if (!success) {
      JOptionPane.showMessageDialog(frame, "You don't have that item.");
    }
    refresh();
  }

  /**
   * Attempts to use an item from the player's inventory.
   *
   * @param item the name of the item to use
   */
  private void useItem(String item) {
    boolean success = model.getPlayer().use(item);
    if (!success) {
      JOptionPane.showMessageDialog(frame, "Can't use that item.");
    }
    refresh();
  }

  /**
   * Attempts to solve a puzzle in the current room with the provided answer.
   *
   * @param answer the answer to the puzzle
   */
  private void answerPuzzle(String answer) {
    boolean success = model.getPlayer().solve(answer);
    if (!success) {
      JOptionPane.showMessageDialog(frame, "That answer didn't work.");
    }
    refresh();
  }

  /**
   * Refreshes the text display to show the current room and its contents.
   */
  private void refresh() {
    Room current = model.getPlayer().getCurrentRoom();
    gameOutput.setText("You are in: " + current.getName() + "\n" + current.getDescription());
    if (current.getItems() != null && !current.getItems().isEmpty()) {
      gameOutput.append("\nItems here: " + current.getItems());
    }
    if (current.hasActivePuzzle()) {
      gameOutput.append("\nPuzzle blocks your path: " + current.getPuzzleDescription());
    }
  }
}
