package GameEngine.controller;

import GameEngine.model.*;
import java.io.*;
import java.util.Scanner;

/**
 * Controls the game by processing user input and updating the game model.
 * This class handles commands for moving between rooms, taking/dropping items, using items,
 * examining rooms, answering puzzles, and quitting the game.
 */
public class Controller {
  private final GameModel gameModel;
  private final Player player;
  private final Scanner inputscanner;
  private final PrintStream output;

  /**
   * Constructs a new Controller.
   *
   * @param gameModel the game model containing game data.
   * @param input     the source of user input.
   * @param output    the destination for output.
   */
  public Controller(GameModel gameModel, Readable input, Appendable output) {
    this.gameModel = gameModel;
    // Initialize the player with a starting room (e.g., "Cave Entrance")
    this.player = new Player("Player1", gameModel.getRoom("Cave Entrance"));
    this.inputscanner = new Scanner(input);
    this.output = new PrintStream((OutputStream) output);
  }

  /**
   * Runs the game loop.
   * <p>
   * Prompts the user for input and processes commands until the user quits.
   * </p>
   */
  public void run() {
    output.println("Welcome to the game!");
    output.print("Please enter your name: ");
    String playerName = inputscanner.nextLine().trim();
    player.setName(playerName);

    output.println("Hello, " + playerName + "! Let's play!");
    showRoomDetails();

    while (true) {
      output.print("\nWhat do you want to do? (N/S/E/W, T/D/X/L/U/I/A/Q): ");
      String command = inputscanner.nextLine().trim().toUpperCase();

      if (command.equals("Q")) {
        output.println("Goodbye!");
        break;
      }
      processCommand(command);
    }
  }

  /**
   * Processes a single command entered by the user.
   *
   * @param command the command to process.
   */
  public void processCommand(String command) {
    switch (command) {
      case "N":
      case "S":
      case "E":
      case "W":
        movePlayer(command);
        break;
      case "T":
        takeItem();
        break;
      case "I":
        showInventory();
        break;
      case "L":
        showRoomDetails();
        break;
      case "D":
        dropItem();
        break;
      case "A":
        answerPuzzle();
        break;
      case "U":
        useItem();
        break;
      case "X":
        examineRoom();
        break;
      case "Q":
        output.println("Goodbye!");
        break;
      default:
        output.println("Invalid command!");
    }
  }

  /**
   * Displays details about the current room, including its name, description,
   * available items, puzzle, and fixtures.
   */
  private void showRoomDetails() {
    Room currentRoom = player.getCurrentRoom();
    if (currentRoom == null) {
      output.println("No current room is set.");
      return;
    }
    output.println("You are in: " + currentRoom.getRoomName());
    output.println(currentRoom.getDescription());
    if (currentRoom.getItems() != null && !currentRoom.getItems().trim().isEmpty()) {
      output.println("Items available: " + currentRoom.getItems());
    }
    if (currentRoom.getPuzzle() != null && !currentRoom.getPuzzle().trim().isEmpty()) {
      output.println("There is a puzzle here: " + currentRoom.getPuzzle());
    }
    if (currentRoom.getFixtures() != null && !currentRoom.getFixtures().trim().isEmpty()) {
      output.println("Fixtures: " + currentRoom.getFixtures());
    }
  }

  /**
   * Moves the player in the specified direction if an exit exists.
   *
   * @param direction the direction to move (N, S, E, or W).
   */
  private void movePlayer(String direction) {
    Room currentRoom = player.getCurrentRoom();
    if (currentRoom == null) {
      output.println("Error: Current room not set.");
      return;
    }
    Room nextRoom = currentRoom.getExits().get(direction);
    if (nextRoom == null) {
      output.println("You can't move in that direction!");
    } else {
      player.move(direction);
      player.setCurrentRoom(nextRoom);
      output.println("You moved " + direction);
      showRoomDetails();
    }
  }

  /**
   * Allows the player to take an item from the current room.
   */
  private void takeItem() {
    Room currentRoom = player.getCurrentRoom();
    if (currentRoom == null) {
      output.println("No current room.");
      return;
    }
    String roomItems = currentRoom.getItems();
    if (roomItems == null || roomItems.trim().isEmpty()) {
      output.println("There are no items to take in this room.");
      return;
    }
    // For simplicity, take the first item in the comma-separated list.
    String[] itemArray = roomItems.split(",");
    String itemName = itemArray[0].trim();
    Item item = gameModel.getItem(itemName);
    if (item == null) {
      output.println("Item " + itemName + " not found in game model.");
      return;
    }
    player.getInventory().add(item);
    output.println("You picked up: " + item.getName());
    // Remove the taken item from the room's items list.
    if (itemArray.length > 1) {
      StringBuilder sb = new StringBuilder();
      for (int i = 1; i < itemArray.length; i++) {
        if (i > 1) sb.append(", ");
        sb.append(itemArray[i].trim());
      }
      currentRoom.setItems(sb.toString());
    } else {
      currentRoom.setItems("");
    }
  }

  /**
   * Displays the items in the player's inventory.
   */
  private void showInventory() {
    if (player.getInventory().isEmpty()) {
      output.println("Your inventory is empty.");
      return;
    }
    output.println("You are carrying:");
    for (Item item : player.getInventory()) {
      output.println("- " + item.getName());
    }
  }

  /**
   * Allows the player to drop an item from their inventory.
   * The item is added back to the current room's item list.
   */
  private void dropItem() {
    if (player.getInventory().isEmpty()) {
      output.println("You have no items to drop.");
      return;
    }
    output.println("Which item would you like to drop? (Enter item name)");
    String itemName = inputscanner.nextLine().trim();
    Item itemToDrop = null;
    for (Item item : player.getInventory()) {
      if (item.getName().equalsIgnoreCase(itemName)) {
        itemToDrop = item;
        break;
      }
    }
    if (itemToDrop == null) {
      output.println("You don't have that item.");
      return;
    }
    player.getInventory().remove(itemToDrop);
    Room currentRoom = player.getCurrentRoom();
    String currentItems = currentRoom.getItems();
    if (currentItems == null || currentItems.trim().isEmpty()) {
      currentRoom.setItems(itemToDrop.getName());
    } else {
      currentRoom.setItems(currentItems + ", " + itemToDrop.getName());
    }
    output.println("You dropped: " + itemToDrop.getName());
  }

  /**
   * Processes the player's answer to a puzzle in the current room.
   */
  private void answerPuzzle() {
    Room currentRoom = player.getCurrentRoom();
    if (currentRoom == null) {
      output.println("No current room.");
      return;
    }
    String puzzleName = currentRoom.getPuzzle();
    if (puzzleName == null || puzzleName.trim().isEmpty()) {
      output.println("There is no puzzle in this room.");
      return;
    }
    Puzzle puzzle = gameModel.getPuzzle(puzzleName);
    if (puzzle == null) {
      output.println("Puzzle not found in game model.");
      return;
    }
    if (!puzzle.isActive()) {
      output.println("The puzzle has already been solved.");
      return;
    }
    output.println("Puzzle: " + puzzle.getName());
    output.print("Enter your answer: ");
    String answer = inputscanner.nextLine().trim();
    if (answer.equalsIgnoreCase(puzzle.getSolution())) {
      puzzle.setActive(false);
      output.println("Puzzle solved!");
      currentRoom.setPuzzle("");
    } else {
      output.println("Wrong answer!");
    }
  }

  /**
   * Allows the player to use an item from their inventory.
   * <p>
   * If only one item is in the inventory, it is automatically used.
   * Otherwise, the player is prompted for which item to use.
   * </p>
   */
  private void useItem() {
    if (player.getInventory().isEmpty()) {
      output.println("You have no items to use.");
      return;
    }
    // Automatically use the item if there is only one in the inventory.
    if (player.getInventory().size() == 1) {
      Item itemToUse = player.getInventory().get(0);
      itemToUse.use();
      output.println("You used " + itemToUse.getName() + ". " + itemToUse.getWhenUsed());
      if (itemToUse.getUsesRemaining() <= 0) {
        output.println("The " + itemToUse.getName() + " is now used up and removed from your inventory.");
        player.getInventory().remove(itemToUse);
      }
      return;
    }
    // If there are multiple items, prompt the user.
    output.println("Which item would you like to use? (Enter item name)");
    String itemName = inputscanner.nextLine().trim();
    Item itemToUse = null;
    for (Item item : player.getInventory()) {
      if (item.getName().equalsIgnoreCase(itemName)) {
        itemToUse = item;
        break;
      }
    }
    if (itemToUse == null) {
      output.println("You don't have that item.");
      return;
    }
    itemToUse.use();
    output.println("You used " + itemToUse.getName() + ". " + itemToUse.getWhenUsed());
    if (itemToUse.getUsesRemaining() <= 0) {
      output.println("The " + itemToUse.getName() + " is now used up and removed from your inventory.");
      player.getInventory().remove(itemToUse);
    }
  }

  /**
   * Displays detailed information about the current room.
   */
  private void examineRoom() {
    Room currentRoom = player.getCurrentRoom();
    if (currentRoom == null) {
      output.println("No current room.");
      return;
    }
    output.println("Examining room: " + currentRoom.getRoomName());
    output.println(currentRoom.getDescription());
    if (currentRoom.getFixtures() != null && !currentRoom.getFixtures().trim().isEmpty()) {
      output.println("Fixtures: " + currentRoom.getFixtures());
    }
  }
}
