package GameEngine.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * Represents the game model that loads and processes game data from a JSON file.
 * This class deserializes the game data, creates mappings for game entities, and sets up
 * relationships such as linking rooms based on directional exits.
 */
public class GameModel {
  private Map<String, Room> rooms;
  private Map<String, Item> items;
  private Map<String, Puzzle> puzzles;
  private Map<String, Monster> monsters;
  private Map<String, Fixture> fixtures;
  private Player player;

  /**
   * Constructs a GameModel by loading game data from the specified JSON file.
   *
   * @param gameFileName the path to the game JSON file.
   */
  public GameModel(String gameFileName) {
    rooms = new HashMap<>();
    items = new HashMap<>();
    puzzles = new HashMap<>();
    monsters = new HashMap<>();
    fixtures = new HashMap<>();

    try {
      ObjectMapper mapper = new ObjectMapper();
      GameData gameData = mapper.readValue(new File(gameFileName), GameData.class);

      List<Room> roomList = gameData.getRooms();
      Map<String, Room> roomByNumber = new HashMap<>();
      if (roomList != null) {
        for (Room room : roomList) {
          roomByNumber.put(room.getRoomNumber(), room);
          rooms.put(room.getRoomName(), room);
        }
      }

      if (roomList != null) {
        for (Room room : roomList) {
          addExitIfValid(room, "N", room.getNorth(), roomByNumber);
          addExitIfValid(room, "S", room.getSouth(), roomByNumber);
          addExitIfValid(room, "E", room.getEast(), roomByNumber);
          addExitIfValid(room, "W", room.getWest(), roomByNumber);
        }
      }

      List<Item> itemList = gameData.getItems();
      if (itemList != null) {
        for (Item item : itemList) {
          items.put(item.getName(), item);
        }
      }

      List<Puzzle> puzzleList = gameData.getPuzzles();
      if (puzzleList != null) {
        for (Puzzle puzzle : puzzleList) {
          puzzles.put(puzzle.getName(), puzzle);
        }
      }

      List<Monster> monsterList = gameData.getMonsters();
      if (monsterList != null) {
        for (Monster monster : monsterList) {
          monsters.put(monster.getName(), monster);
        }
      }

      List<Fixture> fixtureList = gameData.getFixtures();
      if (fixtureList != null) {
        for (Fixture fixture : fixtureList) {
          fixtures.put(fixture.getName(), fixture);
        }
      }

      // Initialize player in the first room if available
      if (roomList != null && !roomList.isEmpty()) {
        this.player = new Player("Player", roomList.get(0));
      } else {
        throw new IllegalStateException("Game must have at least one room to place the player.");
      }

      System.out.println("Game loaded successfully!");
    } catch (IOException e) {
      System.err.println("Failed to load game data: " + e.getMessage());
    }
  }

  private void addExitIfValid(Room room, String direction, String roomNumber, Map<String, Room> roomByNumber) {
    if (roomNumber != null && !roomNumber.equals("0")) {
      Room exitRoom = roomByNumber.get(roomNumber);
      if (exitRoom != null) {
        room.addExit(direction, exitRoom);
      }
    }
  }

  public void save(String filePath) throws IOException {
    ObjectMapper mapper = new ObjectMapper();
    GameData data = new GameData();
    data.setRooms(List.copyOf(rooms.values()));
    data.setItems(List.copyOf(items.values()));
    data.setPuzzles(List.copyOf(puzzles.values()));
    data.setMonsters(List.copyOf(monsters.values()));
    data.setFixtures(List.copyOf(fixtures.values()));
    mapper.writerWithDefaultPrettyPrinter().writeValue(new File(filePath), data);
  }

  public static GameModel load(String filePath) throws IOException {
    return new GameModel(filePath);
  }

  public Room getRoom(String name) {
    return rooms.get(name);
  }

  public Item getItem(String name) {
    return items.get(name);
  }

  public Puzzle getPuzzle(String name) {
    return puzzles.get(name);
  }

  public Monster getMonster(String name) {
    return monsters.get(name);
  }

  public Fixture getFixture(String name) {
    return fixtures.get(name);
  }

  public Player getPlayer() {
    return player;
  }
}
