package GameEngine.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents a monster that may block the player's progress.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Monster {

  @JsonProperty("name")
  private String name;

  @JsonProperty("solution")
  private String solution;

  @JsonProperty("active")
  private boolean active;

  @JsonProperty("value")
  private int value;

  @JsonProperty("damage")
  private int damage;

  /**
   * Default constructor for Jackson deserialization.
   */
  public Monster() { }

  /**
   * Returns the monster's name.
   *
   * @return the monster name.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns whether the monster is active.
   *
   * @return true if active, false otherwise.
   */
  public boolean isActive() {
    return active;
  }

  /**
   * Returns the solution that defeats the monster.
   *
   * @return the solution string.
   */
  public String getSolution() {
    return solution;
  }

  /**
   * Returns the monster's value.
   *
   * @return the value.
   */
  public int getValue() {
    return value;
  }

  /**
   * Returns the damage inflicted by the monster.
   *
   * @return the damage value.
   */
  public int getDamage() {
    return damage;
  }
}

