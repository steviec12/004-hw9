package GameEngine.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

/**
 * Represents the raw game data structure as defined in the JSON file.
 * <p>
 * This class is used by Jackson to deserialize the game file.
 * </p>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GameData {
  private String name;
  private String version;
  private List<Room> rooms;
  private List<Item> items;
  private List<Puzzle> puzzles;
  private List<Monster> monsters;
  private List<Fixture> fixtures;

  /**
   * Returns the game name.
   *
   * @return the game name.
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the game name.
   *
   * @param name the game name.
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Returns the version of the game data.
   *
   * @return the version.
   */
  public String getVersion() {
    return version;
  }

  /**
   * Sets the game data version.
   *
   * @param version the version to set.
   */
  public void setVersion(String version) {
    this.version = version;
  }

  /**
   * Returns the list of rooms.
   *
   * @return the list of rooms.
   */
  public List<Room> getRooms() {
    return rooms;
  }

  /**
   * Sets the list of rooms.
   *
   * @param rooms the list of rooms.
   */
  public void setRooms(List<Room> rooms) {
    this.rooms = rooms;
  }

  /**
   * Returns the list of items.
   *
   * @return the list of items.
   */
  public List<Item> getItems() {
    return items;
  }

  /**
   * Sets the list of items.
   *
   * @param items the list of items.
   */
  public void setItems(List<Item> items) {
    this.items = items;
  }

  /**
   * Returns the list of puzzles.
   *
   * @return the list of puzzles.
   */
  public List<Puzzle> getPuzzles() {
    return puzzles;
  }

  /**
   * Sets the list of puzzles.
   *
   * @param puzzles the list of puzzles.
   */
  public void setPuzzles(List<Puzzle> puzzles) {
    this.puzzles = puzzles;
  }

  /**
   * Returns the list of monsters.
   *
   * @return the list of monsters.
   */
  public List<Monster> getMonsters() {
    return monsters;
  }

  /**
   * Sets the list of monsters.
   *
   * @param monsters the list of monsters.
   */
  public void setMonsters(List<Monster> monsters) {
    this.monsters = monsters;
  }

  /**
   * Returns the list of fixtures.
   *
   * @return the list of fixtures.
   */
  public List<Fixture> getFixtures() {
    return fixtures;
  }

  /**
   * Sets the list of fixtures.
   *
   * @param fixtures the list of fixtures.
   */
  public void setFixtures(List<Fixture> fixtures) {
    this.fixtures = fixtures;
  }
}
