package GameEngine.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents a puzzle that can block progress in the game.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Puzzle {
  private String name;
  private String solution;
  private boolean active;

  /**
   * Returns the puzzle's name.
   *
   * @return the puzzle name.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns whether the puzzle is active.
   *
   * @return true if active, false otherwise.
   */
  public boolean isActive() {
    return active;
  }

  /**
   * Returns the solution for the puzzle.
   *
   * @return the solution string.
   */
  public String getSolution() {
    return solution;
  }

  /**
   * Sets the active state of the puzzle.
   *
   * @param b true to set the puzzle active, false to deactivate.
   */
  public void setActive(boolean b) {
    active = b;
  }
}

