package GameEngine.model;

/**
 * Represents a static object in a room.
 */
public class Fixture {
  private String name;
  private String description;

  /**
   * Returns the fixture's name.
   * @return fixture name
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the fixture's name.
   * @param name fixture name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Returns the fixture's description.
   * @return description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets the fixture's description.
   * @param description fixture description
   */
  public void setDescription(String description) {
    this.description = description;
  }
}
