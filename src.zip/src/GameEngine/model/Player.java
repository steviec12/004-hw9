package GameEngine.model;

import java.util.List;
import java.util.ArrayList;


public class Player {
  private String name;
  private Room currentRoom;
  private List<Item> inventory = new ArrayList<>();


  public Player(String name, Room startingRoom) {
    this.name = name;
    this.currentRoom = startingRoom;
  }

  // Basic getters and setters

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Room getCurrentRoom() {
    return currentRoom;
  }

  public void setCurrentRoom(Room room) {
    this.currentRoom = room;
  }



  public List<Item> getInventory() {
    return inventory;
  }

  public void addToInventory(Item item) {
    inventory.add(item);
  }

  public boolean removeFromInventory(Item item) {
    return inventory.remove(item);
  }


  // Movement logic (basic walk-around)

  public boolean move(String direction) {
    Room current = this.getCurrentRoom();
    Room next = current.getExit(direction);

    if (next == null) {
      System.out.println("You can't go " + direction + ". There's a wall or no exit.");
      return false;
    }

    if (current.hasPuzzle()) {
      System.out.println("A puzzle blocks your way. Solve it first.");
      return false;
    }

    if (current.hasMonster()) {
      System.out.println("A monster blocks your way. Defeat it first.");
      return false;
    }

    this.setCurrentRoom(next);
    System.out.println("You moved " + direction + " to: " + next.getName());
    return true;
  }



  public boolean take(String itemName) {
    System.out.println("Taking item: " + itemName);
    return true;
  }

  public boolean drop(String itemName) {
    System.out.println("Dropping item: " + itemName);
    return true;
  }


  public boolean use(String itemName) {
    System.out.println("Using item: " + itemName);
    return inventory.contains(itemName); // Example placeholder
  }

  public boolean solve(String answer) {
    System.out.println("Solving puzzle with answer: " + answer);
    return true;
  }
}
