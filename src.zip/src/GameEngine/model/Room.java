package GameEngine.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Map;
import java.util.HashMap;

/**
 * A room in the game world.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Room {

  @JsonProperty("room_name")
  private String roomName;

  private String description;

  private Map<String, Room> exits;

  @JsonProperty("N")
  private String north;
  @JsonProperty("S")
  private String south;
  @JsonProperty("E")
  private String east;
  @JsonProperty("W")
  private String west;

  @JsonProperty("room_number")
  private String roomNumber;

  @JsonProperty("items")
  private String items;

  @JsonProperty("puzzle")
  private String puzzle;

  @JsonProperty("fixtures")
  private String fixtures;

  @JsonProperty("monster")
  private String monster;

  @JsonProperty("picture")
  private String picture;

  /**
   * Default constructor for deserialization.
   */
  public Room() {
    this.roomName = "";
    this.description = "";
    this.exits = new HashMap<>();
  }

  /**
   * Initializes a room with a name and description.
   */
  public Room(String roomName, String description) {
    this.roomName = roomName;
    this.description = description;
    this.exits = new HashMap<>();
  }

  /** Room metadata **/

  public String getRoomName() {
    return roomName;
  }

  public String getDescription() {
    return description;
  }

  public String getRoomNumber() {
    return roomNumber;
  }

  public String getNorth() { return north; }
  public String getSouth() { return south; }
  public String getEast()  { return east; }
  public String getWest()  { return west; }

  public String getItems() {
    return items;
  }

  public void setItems(String items) {
    this.items = items;
  }

  public String getFixtures() {
    return fixtures;
  }

  public void setFixtures(String fixtures) {
    this.fixtures = fixtures;
  }

  public String getPuzzle() {
    return puzzle;
  }

  public void setPuzzle(String puzzle) {
    this.puzzle = puzzle;
  }

  public String getMonster() {
    return monster;
  }

  public void setMonster(String monster) {
    this.monster = monster;
  }

  public String getPicture() {
    return picture;
  }

  public void setPicture(String picture) {
    this.picture = picture;
  }

  /** Game logic **/

  public Map<String, Room> getExits() {
    return exits;
  }

  public void addExit(String direction, Room room) {
    exits.put(direction, room);
  }

  public Room getExit(String direction) {
    return exits.get(direction);
  }

  public String getName() {
    return this.roomName;
  }

  public boolean hasActivePuzzle() {
    return puzzle != null && !puzzle.trim().isEmpty();
  }

  public boolean hasPuzzle() {
    return puzzle != null && !puzzle.trim().isEmpty();
  }

  public boolean hasMonster() {
    return monster != null && !monster.trim().isEmpty();
  }

  public String getPuzzleDescription() {
    if (puzzle != null && !puzzle.trim().isEmpty()) {
      return puzzle;
    } else {
      return "No puzzle here.";
    }
  }
}
