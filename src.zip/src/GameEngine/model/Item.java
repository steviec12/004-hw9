package GameEngine.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents an item that can be picked up and used by the player.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Item {

  @JsonProperty("name")
  public String name;

  @JsonProperty("weight")
  private int weight;

  @JsonProperty("value")
  private int value;

  @JsonProperty("max_uses")
  public int maxUses;

  @JsonProperty("uses_remaining")
  public int usesRemaining;

  @JsonProperty("when_used")
  private String whenUsed;

  /**
   * Default constructor for Jackson deserialization.
   */
  public Item() { }

  /**
   * Returns the item name.
   *
   * @return the item name.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the item weight.
   *
   * @return the weight.
   */
  public int getWeight() {
    return weight;
  }

  /**
   * Returns the item value.
   *
   * @return the value.
   */
  public int getValue() {
    return value;
  }

  /**
   * Returns the maximum number of uses for this item.
   *
   * @return the maximum uses.
   */
  public int getMaxUses() {
    return maxUses;
  }

  /**
   * Returns the number of remaining uses.
   *
   * @return the remaining uses.
   */
  public int getUsesRemaining() {
    return usesRemaining;
  }

  /**
   * Returns the text displayed when the item is used.
   *
   * @return the when-used text.
   */
  public String getWhenUsed() {
    return whenUsed;
  }

  /**
   * Decrements the remaining uses of the item by one.
   */
  public void use() {
    usesRemaining--;
  }

  @Override
  public String toString() {
    return String.format("%s (Value: %d, Weight: %d, Uses: %d/%d)",
            name, value, weight, usesRemaining, maxUses);
  }

}
