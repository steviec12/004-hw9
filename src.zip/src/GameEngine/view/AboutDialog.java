package GameEngine.view;

import java.awt.*;

import javax.swing.*;

public class AboutDialog extends JDialog {
  public AboutDialog(JFrame parent) {
    super(parent, "About", true);
    setLayout(new BorderLayout());
    setSize(300, 300);
    setLocationRelativeTo(parent);

    JLabel text = new JLabel(
            "<html><center><h2>Adventure Game</h2><p>Built by The Five</p><p>Spring 2025</p></center></html>",
            SwingConstants.CENTER
    );
    add(text, BorderLayout.CENTER);

    JButton ok = new JButton("OK");
    ok.addActionListener(e -> dispose());
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(ok);
    add(buttonPanel, BorderLayout.SOUTH);
  }
}
