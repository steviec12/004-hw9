package GameEngine.view;

import java.awt.*;
import java.net.URL;

import javax.swing.*;

public class MainGameView extends JFrame {
  private JLabel roomImageLabel;
  public MainGameView() {
    super("Adventure Game - The Five");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(800, 600);
    setLocationRelativeTo(null);
    setLayout(new BorderLayout());
    setupMenuBar();
    setupRoomImagePanel();
    setVisible(true);
  }

  private void setupMenuBar() {
    JMenuBar menubar = new JMenuBar();
    JMenu gameMenu = new JMenu("Game");
    JMenuItem aboutItem = new JMenuItem("About");
    aboutItem.addActionListener(e -> new AboutDialog(this).setVisible(true));
    JMenuItem quitItem = new JMenuItem("Quit");
    quitItem.addActionListener(e -> new QuitConfirmDialog(this).setVisible(true));
    gameMenu.add(aboutItem);
    gameMenu.add(quitItem);
    menubar.add(gameMenu);
    setJMenuBar(menubar);
  }

  private void setupRoomImagePanel() {
  roomImageLabel = new JLabel();
  roomImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
  roomImageLabel.setVerticalAlignment(SwingConstants.CENTER);
  add(roomImageLabel, BorderLayout.CENTER);
  }

  public void setRoomImages(String imageName) {
    ImageIcon icon = loadImage(imageName);
    if (icon != null) {
      Image scaled = icon.getImage().getScaledInstance(600, 400, Image.SCALE_SMOOTH);
      roomImageLabel.setIcon(new ImageIcon(scaled));
    } else {
      ImageIcon fallback = loadImage("generic_location.png");
      if (fallback != null) {
        Image scaled = fallback.getImage().getScaledInstance(600, 400, Image.SCALE_SMOOTH);
        roomImageLabel.setIcon(new ImageIcon(scaled));
      } else {
        roomImageLabel.setText("Image error");
      }
    }
  }

  private ImageIcon loadImage(String imageName) {
    try {
      URL url = getClass().getClassLoader().getResource("images/" +imageName);
      return url != null ? new ImageIcon(url) : null;
    } catch (Exception e) {
      return null;
    }
  }
}