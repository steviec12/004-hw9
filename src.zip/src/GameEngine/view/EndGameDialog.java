package GameEngine.view;

import java.awt.*;

import javax.swing.*;

public class EndGameDialog extends JDialog {

  public EndGameDialog(JFrame parent, boolean isVictory) {
    super(parent, isVictory ? "Win" : "Game Over", true);
    setLayout(new BorderLayout());
    setSize(400, 250);
    setLocationRelativeTo(parent);

    String image = isVictory ? "congratulations.png" : "gameover.png";
    ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource("images/" + image));
    Image scaled = icon.getImage().getScaledInstance(350, 180, Image.SCALE_SMOOTH);
    JLabel label = new JLabel(new ImageIcon(scaled), JLabel.CENTER);
    add(label, BorderLayout.CENTER);

    JButton close = new JButton("Close");
    close.addActionListener(e -> {
      dispose();
      System.exit(0);
    });
    JPanel panel = new JPanel();
    panel.add(close);
    add(panel, BorderLayout.SOUTH);
  }
}
