package GameEngine.view;

import java.awt.*;

import javax.swing.*;

public class QuitConfirmDialog extends JDialog {
  public QuitConfirmDialog(JFrame parent) {
    super(parent, "Quit?", true);
    setLayout(new BorderLayout());
    setSize(300, 150);
    setLocationRelativeTo(parent);

    JLabel label = new JLabel("Quitting?", SwingConstants.CENTER);
    add(label, BorderLayout.CENTER);

    JButton yesButton = new JButton("Yes");
    yesButton.addActionListener(e -> System.exit(0));

    JButton noButton = new JButton("No");
    noButton.addActionListener(e -> dispose());

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(yesButton);
    buttonPanel.add(noButton);
    add(buttonPanel, BorderLayout.SOUTH);
  }
}
