package controller;

import GameEngine.controller.Controller;
import GameEngine.model.*;
import org.junit.Before;
import org.junit.Test;
import java.io.*;
import static org.junit.Assert.*;

/**
 * Unit tests for the Controller class.
 * <p>
 * These tests verify the Controller’s ability to initialize the player, process movement commands,
 * examine the room, take items, display inventory, solve puzzles, use items, and quit the game.
 * </p>
 */
public class ControllerTest {
  private GameModel gameModel;
  private Controller controller;
  private ByteArrayOutputStream output;

  @Before
  public void setUp() throws Exception {
    gameModel = new GameModel("./resources/cave_redhouse.json");
    output = new ByteArrayOutputStream();
    controller = new Controller(
            gameModel,
            new InputStreamReader(new ByteArrayInputStream("TestPlayer\nN\nT\nQ".getBytes())),
            new PrintStream(output)
    );
  }

  /**
   * Tests that the player is properly initialized with the correct name.
   */
  @Test
  public void testPlayerInitialization() {
    controller.run();
    assertTrue(output.toString().contains("Hello, TestPlayer!"));
  }

  /**
   * Tests that a valid movement command ("N") moves the player to a room containing "Tunnel of Shadows".
   */
  @Test
  public void testValidMovement() {
    controller.processCommand("N");
    assertTrue(output.toString().contains("Tunnel of Shadows"));
  }

  /**
   * Tests that the "X" command properly invokes room examination.
   */
  @Test
  public void testExamineRoomCommand() {
    controller.processCommand("X");
    assertTrue(output.toString().contains("Examining room:"));
  }

  /**
   * Tests that taking an item from the room works and outputs the expected messages.
   */
  @Test
  public void testItemTakeFromRoom() {
    controller.processCommand("T");
    assertTrue(output.toString().contains("Torch"));
    assertTrue(output.toString().contains("picked up"));
  }

  /**
   * Tests that the inventory display command shows the correct items.
   */
  @Test
  public void testInventoryDisplay() {
    controller.processCommand("T");
    controller.processCommand("I");
    assertTrue(output.toString().contains("Torch"));
  }

  /**
   * Tests that the puzzle solving command prompts the user for an answer.
   */
  @Test
  public void testPuzzleSolving() {
    controller.processCommand("N"); // Move to room with puzzle
    controller.processCommand("A");
    assertTrue(output.toString().contains("Enter your answer"));
  }

  /**
   * Tests that using an item produces the correct output messages.
   */
  @Test
  public void testItemUsage() {
    controller.processCommand("T");
    controller.processCommand("U");
    assertTrue(output.toString().contains("Torch"));
    assertTrue(output.toString().contains("lights up"));
  }

  /**
   * Tests that the game quit command ("Q") outputs a goodbye message.
   */
  @Test
  public void testGameQuit() {
    controller.processCommand("Q");
    assertTrue(output.toString().contains("Goodbye!"));
  }
}
