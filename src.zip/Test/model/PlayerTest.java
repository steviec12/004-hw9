package model;

import org.junit.Before;
import org.junit.Test;
import GameEngine.model.Item;
import GameEngine.model.Player;
import GameEngine.model.Room;
import static org.junit.Assert.*;

/**
 * Unit tests for the Player class.
 * <p>
 * These tests verify that inventory management, health status, and score-based rank calculation
 * function as expected.
 * </p>
 */
public class PlayerTest {
  private Player player;
  private Room startRoom;

  @Before
  public void setUp() {
    startRoom = new Room("Test Room", "A testing room");
    player = new Player("Tester", startRoom);
  }

  /**
   * Tests that items can be added to the player's inventory.
   */
  @Test
  public void testInventoryManagement() {
    Item item = new Item();
    item.name = "TestItem";
    player.getInventory().add(item);

    assertFalse(player.getInventory().isEmpty());
    assertEquals("TestItem", player.getInventory().get(0).getName());
  }

  /**
   * Tests that the player's health status is determined correctly.
   */
  @Test
  public void testHealthStatus() {
    player.health = 30;
    assertTrue(player.getHealthStatus().contains("WOOZY"));
  }

  /**
   * Tests that the player's rank is calculated correctly based on the score.
   */
  @Test
  public void testScoreCalculation() {
    player.score = 150;
    assertTrue(player.getRank().contains("Gold"));
  }
}
