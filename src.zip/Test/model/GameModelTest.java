package model;

import org.junit.Before;
import org.junit.Test;
import GameEngine.model.GameModel;
import GameEngine.model.Item;
import GameEngine.model.Monster;
import GameEngine.model.Puzzle;
import GameEngine.model.Room;
import static org.junit.Assert.*;

/**
 * Unit tests for the GameModel class.
 * <p>
 * These tests verify that game data (rooms, items, puzzles, and monsters) is correctly loaded from the JSON file,
 * and that invalid data is handled appropriately.
 * </p>
 */
public class GameModelTest {
  private GameModel gameModel;

  @Before
  public void setUp() throws Exception {
    gameModel = new GameModel("./resources/cave_redhouse.json");
  }

  /**
   * Tests that a room ("Cave Entrance") is loaded correctly.
   */
  @Test
  public void testRoomLoading() {
    Room room = gameModel.getRoom("Cave Entrance");
    assertNotNull(room);
    assertEquals("1", room.getRoomNumber());
  }

  /**
   * Tests that an item ("Torch") is loaded with the correct weight.
   */
  @Test
  public void testItemLoading() {
    Item item = gameModel.getItem("Torch");
    assertNotNull(item);
    assertEquals(2, item.getWeight());
  }

  /**
   * Tests that a puzzle ("Rune Lock") is loaded with the correct solution.
   */
  @Test
  public void testPuzzleLoading() {
    Puzzle puzzle = gameModel.getPuzzle("Rune Lock");
    assertNotNull(puzzle);
    assertEquals("Torch", puzzle.getSolution());
  }

  /**
   * Tests that a monster ("CaveStalker") is loaded with the correct damage.
   */
  @Test
  public void testMonsterLoading() {
    Monster monster = gameModel.getMonster("CaveStalker");
    assertNotNull(monster);
    assertEquals(5, monster.getDamage());
  }

  /**
   * Tests that invalid data is handled gracefully (e.g., a room that doesn't exist).
   */
  @Test
  public void testInvalidDataHandling() {
    GameModel invalidModel = new GameModel("invalid.json");
    assertNull(invalidModel.getRoom("GhostRoom"));
  }
}
