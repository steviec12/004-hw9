package model;

import org.junit.Test;
import GameEngine.model.Item;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for the Item class.
 * <p>
 * These tests verify that using an item decrements its remaining uses and that an expired item
 * is correctly handled.
 * </p>
 */
public class ItemTest {

  /**
   * Tests that using an item decrements the remaining uses.
   */
  @Test
  public void testItemUsage() {
    Item torch = new Item();
    torch.name = "Torch";
    torch.usesRemaining = 3;

    torch.use();
    assertEquals(2, torch.getUsesRemaining());
  }

  /**
   * Tests that an item with only one remaining use becomes expired after use.
   */
  @Test
  public void testExpiredItem() {
    Item key = new Item();
    key.maxUses = 1;
    key.usesRemaining = 1;

    key.use();
    assertTrue(key.getUsesRemaining() <= 0);
  }
}
