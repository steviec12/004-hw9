package model;

import org.junit.Test;
import GameEngine.model.Fixture;
import static org.junit.Assert.*;

/**
 * Unit tests for the Fixture class.
 * <p>
 * These tests verify that the Fixture's properties (name and description) can be set and retrieved correctly.
 * </p>
 */
public class FixtureTest {

  /**
   * Tests setting and getting the Fixture's name and description.
   */
  @Test
  public void testFixtureProperties() {
    Fixture fixture = new Fixture();
    fixture.setName("Stone Arch");
    fixture.setDescription("A stone arch with ancient carvings.");

    assertEquals("Stone Arch", fixture.getName());
    assertEquals("A stone arch with ancient carvings.", fixture.getDescription());
  }

  /**
   * Tests that a newly created Fixture has null name and description by default.
   */
  @Test
  public void testFixtureDefaultValues() {
    Fixture fixture = new Fixture();
    assertNull(fixture.getName());
    assertNull(fixture.getDescription());
  }
}
