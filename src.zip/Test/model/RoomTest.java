package model;

import org.junit.Test;
import GameEngine.model.Room;
import static org.junit.Assert.*;

/**
 * Unit tests for the Room class.
 * <p>
 * These tests verify that exits can be added to a room and that the room's item list
 * is handled correctly.
 * </p>
 */
public class RoomTest {

  /**
   * Tests that an exit is correctly added and retrieved from a room.
   */
  @Test
  public void testExitManagement() {
    Room room1 = new Room("Room1", "Test Room 1");
    Room room2 = new Room("Room2", "Test Room 2");

    room1.addExit("N", room2);
    assertEquals(room2, room1.getExits().get("N"));
  }

  /**
   * Tests that setting and getting the room's item list works correctly.
   */
  @Test
  public void testItemListHandling() {
    Room room = new Room("TestRoom", "Testing");
    room.setItems("Sword, Shield");
    assertEquals("Sword, Shield", room.getItems());
  }
}
